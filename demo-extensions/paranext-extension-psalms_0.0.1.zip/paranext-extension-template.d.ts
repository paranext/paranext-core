import type { DataProviderDataType } from "shared/models/data-provider.model";
import type IDataProvider from "shared/models/data-provider.interface";
